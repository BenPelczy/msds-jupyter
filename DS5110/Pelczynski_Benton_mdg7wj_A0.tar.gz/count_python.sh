#!/bin/bash
unzip stackoverflow.zip
grep -c "python" questions.csv question_tags.csv
